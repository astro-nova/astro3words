# astro-3-words
What 3 words implementation for astronomical objects
