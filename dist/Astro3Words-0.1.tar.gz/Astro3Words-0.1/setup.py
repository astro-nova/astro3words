from os import name
from setuptools import setup, find_packages

setup(
    name = "Astro3Words",
    version = "0.1",
    packages = find_packages()
)